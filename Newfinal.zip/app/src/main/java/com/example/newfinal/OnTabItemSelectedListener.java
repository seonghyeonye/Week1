package com.example.newfinal;

import android.view.View;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
}

